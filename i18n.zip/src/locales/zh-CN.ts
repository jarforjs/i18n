export default {
  WELCOME_TO_UMI_WORLD: "{name}, 欢迎来到umi的世界",

};
