// @ts-nocheck
import { Plugin } from '/Users/hongbo/Desktop/i18n/node_modules/_@umijs_runtime@3.4.25@@umijs/runtime';

const plugin = new Plugin({
  validKeys: ['modifyClientRenderOpts','patchRoutes','rootContainer','render','onRouteChange','getInitialState','initialStateConfig','locale','request',],
});

export { plugin };
